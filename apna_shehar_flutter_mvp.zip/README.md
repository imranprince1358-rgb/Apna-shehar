# Apna Shehar — Safdarabad MVP

Blue-theme Flutter starter for a local marketplace and personal-shopping/delivery app.

## Included
- Home
- Buy / Request form
- Sell form
- Orders placeholder
- Chat placeholder
- Profile placeholder
- Safdarabad branding

## Run
1. Install Flutter SDK.
2. Open this folder in Android Studio or VS Code.
3. Run `flutter pub get`.
4. Run `flutter run`.

## Next development phase
Connect Firebase for OTP authentication, Firestore orders/products, image storage,
notifications and real-time chat, then build the admin panel.
